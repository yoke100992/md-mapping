import React, { useState } from 'react';
import {
    AppBar,
    Toolbar,
    Typography,
    IconButton,
    Drawer,
    List,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Box,
    useMediaQuery,
    useTheme,
    Avatar,
    Badge,
} from '@mui/material';
import {
    Menu as MenuIcon,
    Upload as UploadIcon,
    Map as MapIcon,
    Dashboard as DashboardIcon,
    Download as DownloadIcon,
    Edit as EditIcon, // <-- TAMBAHKAN INI
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';
import { useData } from '../context/DataContext';

const DRAWER_WIDTH = 260;

const Layout = ({ children }) => {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('md'));
    const [drawerOpen, setDrawerOpen] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();
    const { outlets } = useData();

    const menuItems = [
        { label: 'Dashboard', icon: <DashboardIcon />, path: '/' },
        { label: 'Kelola Outlet', icon: <EditIcon />, path: '/manage' },
        { label: 'Upload Data', icon: <UploadIcon />, path: '/upload' },
        { label: 'View Map', icon: <MapIcon />, path: '/map' },

        { label: 'Download Template', icon: <DownloadIcon />, path: '/template' },
    ];

    const handleNavigate = (path) => {
        navigate(path);
        if (isMobile) setDrawerOpen(false);
    };

    const drawer = (
        <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <Box
                sx={{
                    p: 3,
                    background: 'linear-gradient(135deg, #C41E3A 0%, #E8455A 100%)',
                    color: 'white',
                }}
            >
                <Typography variant="h6" fontWeight={700}>
                    ? MD Mapping
                </Typography>
                <Typography variant="body2" sx={{ opacity: 0.9, mt: 0.5 }}>
                    Marketing Distribution Tracker
                </Typography>
            </Box>
            <List sx={{ flex: 1, px: 2, mt: 1 }}>
                {menuItems.map((item) => (
                    <ListItemButton
                        key={item.path}
                        onClick={() => handleNavigate(item.path)}
                        selected={location.pathname === item.path}
                        sx={{
                            borderRadius: 2,
                            mb: 0.5,
                            '&.Mui-selected': {
                                bgcolor: 'rgba(196, 30, 58, 0.1)',
                                color: 'primary.main',
                                '& .MuiListItemIcon-root': { color: 'primary.main' },
                            },
                            '&:hover': { bgcolor: 'rgba(196, 30, 58, 0.05)' },
                        }}
                    >
                        <ListItemIcon sx={{ minWidth: 40 }}>{item.icon}</ListItemIcon>
                        <ListItemText primary={item.label} />
                        {item.path === '/map' && outlets.length > 0 && (
                            <Badge badgeContent={outlets.length} color="primary" />
                        )}
                    </ListItemButton>
                ))}
            </List>
            <Box sx={{ p: 2, borderTop: '1px solid #f0f0f0' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <Avatar sx={{ bgcolor: 'primary.main', width: 36, height: 36 }}>Y</Avatar>
                    <Box>
                        <Typography variant="body2" fontWeight={600}>
                            Yoke
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                            Admin
                        </Typography>
                    </Box>
                </Box>
            </Box>
        </Box>
    );

    return (
        <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
            <AppBar
                position="fixed"
                sx={{
                    zIndex: theme.zIndex.drawer + 1,
                    bgcolor: 'white',
                    color: 'text.primary',
                }}
                elevation={0}
            >
                <Toolbar>
                    <IconButton
                        edge="start"
                        onClick={() => setDrawerOpen(!drawerOpen)}
                        sx={{ mr: 2, color: 'primary.main' }}
                    >
                        <MenuIcon />
                    </IconButton>
                    <Typography variant="h6" fontWeight={700} color="primary.main" sx={{ flex: 1 }}>
                        MD Mapping System
                    </Typography>
                    <Box
                        sx={{
                            bgcolor: 'primary.main',
                            color: 'white',
                            px: 2,
                            py: 0.5,
                            borderRadius: 20,
                            fontSize: 13,
                            fontWeight: 600,
                        }}
                    >
                        {outlets.length} Outlets
                    </Box>
                </Toolbar>
            </AppBar>

            <Drawer
                variant={isMobile ? 'temporary' : 'permanent'}
                open={isMobile ? drawerOpen : true}
                onClose={() => setDrawerOpen(false)}
                sx={{
                    width: DRAWER_WIDTH,
                    flexShrink: 0,
                    '& .MuiDrawer-paper': {
                        width: DRAWER_WIDTH,
                        boxSizing: 'border-box',
                        borderRight: '1px solid #f0f0f0',
                    },
                }}
            >
                {drawer}
            </Drawer>

            <Box
                component="main"
                sx={{
                    flexGrow: 1,
                    p: 3,
                    mt: 8,
                    ml: isMobile ? 0 : `${DRAWER_WIDTH}px`,
                    transition: theme.transitions.create('margin'),
                }}
            >
                {children}
            </Box>
        </Box>
    );
};

export default Layout;