import React, { useState, useMemo } from 'react';
import {
    Card, CardContent, Typography, Box, Chip, FormControl, InputLabel, Select, MenuItem,
    TextField, Grid, Button, Dialog, DialogTitle, DialogContent, DialogActions, IconButton, Checkbox, Alert
} from '@mui/material';
import {
    FilterList as FilterIcon, Close as CloseIcon, Edit as EditIcon, LocationOn as LocationIcon,
    Store as StoreIcon, AcUnit, Whatshot, Air,
    Palette as PaletteIcon, ClearAll as ClearAllIcon, Warning as WarningIcon
} from '@mui/icons-material';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useData } from '../context/DataContext';
import { getFrontlinerColor, RTG_LABELS, COLOR_PICKER_PALETTE } from '../utils/constants';

const MAX_MARKERS = 500; // Batas maksimal marker yang dirender

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const createCustomIcon = (color) => L.divIcon({
    className: 'custom-marker',
    html: `<svg width="25" height="35" viewBox="0 0 30 42"><path d="M15 0C6.716 0 0 6.716 0 15c0 10.5 15 27 15 27s15-16.5 15-27c0-8.284-6.716-15-15-15z" fill="${color}"/><circle cx="15" cy="15" r="6" fill="white" opacity="0.9"/></svg>`,
    iconSize: [25, 35],
    iconAnchor: [12.5, 35],
    popupAnchor: [0, -30],
});

const MapPage = () => {
    const { outlets, frontliners, customColors, updateOutlet, removeOutlet, updateCustomColor } = useData();
    const [filterFrontliner, setFilterFrontliner] = useState([]);
    const [filterAccount, setFilterAccount] = useState([]);
    const [filterRTG, setFilterRTG] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedOutlet, setSelectedOutlet] = useState(null);
    const [editDialog, setEditDialog] = useState(null);
    const [editForm, setEditForm] = useState({});
    const [colorDialog, setColorDialog] = useState(null);
    const [selectedColorName, setSelectedColorName] = useState('');

    const accounts = useMemo(() => [...new Set(outlets.map((o) => o.account).filter(Boolean))], [outlets]);

    const filteredOutlets = useMemo(() => outlets.filter((o) => {
        if (filterFrontliner.length > 0 && !filterFrontliner.includes(o.frontliner)) return false;
        if (filterAccount.length > 0 && !filterAccount.includes(o.account)) return false;
        if (filterRTG.length > 0 && !filterRTG.includes(o.rtgFreezer)) return false;
        if (searchQuery) {
            const q = searchQuery.toLowerCase();
            return o.outletName.toLowerCase().includes(q) || o.outletId.toLowerCase().includes(q) || o.address.toLowerCase().includes(q);
        }
        return true;
    }), [outlets, filterFrontliner, filterAccount, filterRTG, searchQuery]);

    // Batasi marker yang dirender agar tidak berat
    const markersToRender = filteredOutlets.slice(0, MAX_MARKERS);
    const hasMoreMarkers = filteredOutlets.length > MAX_MARKERS;

    const center = useMemo(() => {
        if (markersToRender.length === 0) return [-6.9175, 107.6191];
        const avgLat = markersToRender.reduce((s, o) => s + o.latitude, 0) / markersToRender.length;
        const avgLng = markersToRender.reduce((s, o) => s + o.longitude, 0) / markersToRender.length;
        return [avgLat, avgLng];
    }, [markersToRender]);

    const handleEdit = (outlet) => { setEditForm({ ...outlet }); setEditDialog(outlet); };
    const handleSaveEdit = () => { updateOutlet(editDialog.id, editForm); setEditDialog(null); setSelectedOutlet(null); };
    const handleOpenColorPicker = (frontliner) => { setSelectedColorName(frontliner); setColorDialog(true); };
    const handleSaveColor = (color) => { updateCustomColor(selectedColorName, color); setColorDialog(null); };
    const handleResetColor = () => { updateCustomColor(selectedColorName, null); setColorDialog(null); };
    const getColorForFrontliner = (fl) => getFrontlinerColor(fl, customColors);

    const handleResetFilters = () => {
        setFilterFrontliner([]);
        setFilterAccount([]);
        setFilterRTG([]);
        setSearchQuery('');
    };

    const hasActiveFilters = filterFrontliner.length > 0 || filterAccount.length > 0 || filterRTG.length > 0 || searchQuery !== '';

    const getRTGIcon = (rtg) => {
        if (rtg === 'Freezer') return <AcUnit fontSize="small" sx={{ color: '#2196F3' }} />;
        if (rtg === 'RTG') return <Whatshot fontSize="small" sx={{ color: '#FF9800' }} />;
        if (rtg === 'Chiller') return <Air fontSize="small" sx={{ color: '#4CAF50' }} />;
        return null;
    };

    return (
        <Box>
            <Typography variant="h4" gutterBottom sx={{ color: 'primary.main' }}>??? View Map</Typography>

            {hasMoreMarkers && (
                <Alert severity="warning" sx={{ mb: 2 }}>
                    <b>Terlalu banyak data!</b> Menampilkan {MAX_MARKERS} dari {filteredOutlets.length} outlet.
                    Silakan persempit filter Anda agar peta lebih ringan.
                </Alert>
            )}

            <Card sx={{ mb: 3 }}>
                <CardContent>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2, flexWrap: 'wrap', gap: 1 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <FilterIcon color="primary" />
                            <Typography variant="h6" fontWeight={600}>Filter & Pencarian</Typography>
                        </Box>
                        {hasActiveFilters && (
                            <Button size="small" variant="outlined" color="error" startIcon={<ClearAllIcon />} onClick={handleResetFilters}>
                                Reset Filter
                            </Button>
                        )}
                    </Box>

                    <Grid container spacing={2}>
                        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                            <TextField label="Cari Outlet..." fullWidth size="small" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Nama, ID, atau alamat..." />
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                            <FormControl fullWidth size="small">
                                <InputLabel>Frontliner</InputLabel>
                                <Select multiple value={filterFrontliner} onChange={(e) => setFilterFrontliner(e.target.value)} label="Frontliner"
                                    renderValue={(selected) => (
                                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                            {selected.length === 0 ? <Typography variant="body2" color="text.secondary">Semua</Typography> :
                                                selected.map((value) => (<Chip key={value} label={value.split(' ').slice(0, 2).join(' ')} size="small" sx={{ bgcolor: getColorForFrontliner(value), color: 'white' }} />))
                                            }
                                        </Box>
                                    )}
                                >
                                    {frontliners.map((fl) => (
                                        <MenuItem key={fl} value={fl}>
                                            <Checkbox checked={filterFrontliner.indexOf(fl) > -1} size="small" />
                                            <Typography variant="body2">{fl}</Typography>
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                            <FormControl fullWidth size="small">
                                <InputLabel>Account</InputLabel>
                                <Select multiple value={filterAccount} onChange={(e) => setFilterAccount(e.target.value)} label="Account"
                                    renderValue={(selected) => (
                                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                            {selected.length === 0 ? <Typography variant="body2" color="text.secondary">Semua</Typography> :
                                                selected.map((value) => <Chip key={value} label={value} size="small" />)
                                            }
                                        </Box>
                                    )}
                                >
                                    {accounts.map((acc) => (
                                        <MenuItem key={acc} value={acc}>
                                            <Checkbox checked={filterAccount.indexOf(acc) > -1} size="small" />
                                            <Typography variant="body2">{acc}</Typography>
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
                            <FormControl fullWidth size="small">
                                <InputLabel>RTG / Freezer</InputLabel>
                                <Select multiple value={filterRTG} onChange={(e) => setFilterRTG(e.target.value)} label="RTG / Freezer"
                                    renderValue={(selected) => (
                                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                            {selected.length === 0 ? <Typography variant="body2" color="text.secondary">Semua</Typography> :
                                                selected.map((value) => <Chip key={value} icon={getRTGIcon(value)} label={value} size="small" />)
                                            }
                                        </Box>
                                    )}
                                >
                                    {RTG_LABELS.map((label) => (
                                        <MenuItem key={label} value={label}>
                                            <Checkbox checked={filterRTG.indexOf(label) > -1} size="small" />
                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                {getRTGIcon(label)}
                                                <Typography variant="body2">{label}</Typography>
                                            </Box>
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>
                    </Grid>

                    <Box sx={{ mt: 2, display: 'flex', flexWrap: 'wrap', gap: 1, alignItems: 'center' }}>
                        <Typography variant="body2" fontWeight={600} sx={{ mr: 1 }}>Legend:</Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ mr: 2 }}>(Klik chip untuk ubah warna)</Typography>
                        {frontliners.map((fl) => {
                            const color = getColorForFrontliner(fl);
                            const count = filteredOutlets.filter((o) => o.frontliner === fl).length;
                            const isCustom = customColors[fl];
                            return (
                                <Chip key={fl} label={`${fl.split(' ').slice(0, 2).join(' ')} (${count})${isCustom ? ' ?' : ''}`} size="small"
                                    onClick={() => handleOpenColorPicker(fl)}
                                    sx={{ bgcolor: color, color: 'white', fontWeight: 600, cursor: 'pointer', '&:hover': { opacity: 0.85, transform: 'scale(1.05)' }, transition: 'all 0.2s' }}
                                />
                            );
                        })}
                        <Chip label={`Total: ${filteredOutlets.length}`} size="small" color="primary" variant="outlined" />
                    </Box>
                </CardContent>
            </Card>

            <Card sx={{ overflow: 'hidden' }}>
                <Box sx={{ height: { xs: '60vh', md: '75vh' }, width: '100%' }}>
                    {markersToRender.length > 0 ? (
                        <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }} scrollWheelZoom={true} preferCanvas={true}>
                            <TileLayer attribution='&copy; OpenStreetMap' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                            <>
                                {markersToRender.map((outlet) => (
                                    <Marker key={outlet.id} position={[outlet.latitude, outlet.longitude]} icon={createCustomIcon(getColorForFrontliner(outlet.frontliner))} eventHandlers={{ click: () => setSelectedOutlet(outlet) }}>
                                        <Popup>
                                            <Box sx={{ minWidth: 200 }}>
                                                <Typography variant="subtitle1" fontWeight={700} color="primary.main">{outlet.outletName}</Typography>
                                                <Typography variant="body2" color="text.secondary">ID: {outlet.outletId}</Typography>
                                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 1 }}>
                                                    <StoreIcon fontSize="small" />
                                                    <Typography variant="body2">{outlet.account}</Typography>
                                                </Box>
                                                {outlet.rtgFreezer && outlet.rtgFreezer !== 'None' && (
                                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 1 }}>
                                                        {getRTGIcon(outlet.rtgFreezer)}
                                                        <Chip label={outlet.rtgFreezer} size="small" color={outlet.rtgFreezer === 'Freezer' ? 'info' : 'warning'} />
                                                    </Box>
                                                )}
                                                <Chip label={outlet.frontliner.split(' ').slice(0, 2).join(' ')} size="small" sx={{ bgcolor: getColorForFrontliner(outlet.frontliner), color: 'white', fontWeight: 600, mt: 1 }} />
                                                <Button size="small" variant="contained" startIcon={<EditIcon />} onClick={() => handleEdit(outlet)} fullWidth sx={{ mt: 1 }}>Edit Frontliner</Button>
                                            </Box>
                                        </Popup>
                                    </Marker>
                                ))}
                            </>
                        </MapContainer>
                    ) : (
                        <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', bgcolor: '#f9f9f9' }}>
                            <LocationIcon sx={{ fontSize: 80, color: 'primary.light', mb: 2 }} />
                            <Typography variant="h6" color="text.secondary">Tidak ada outlet yang cocok dengan filter</Typography>
                            {hasActiveFilters && <Button variant="outlined" onClick={handleResetFilters} sx={{ mt: 2 }}>Reset Filter</Button>}
                        </Box>
                    )}
                </Box>
            </Card>

            {selectedOutlet && (
                <Card sx={{ mt: 3 }}>
                    <CardContent>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                            <Typography variant="h6" fontWeight={600}>?? Detail Outlet</Typography>
                            <IconButton onClick={() => setSelectedOutlet(null)} size="small"><CloseIcon /></IconButton>
                        </Box>
                        <Typography variant="body1"><b>Nama:</b> {selectedOutlet.outletName}</Typography>
                        <Typography variant="body2" color="text.secondary">ID: {selectedOutlet.outletId} | Account: {selectedOutlet.account}</Typography>
                        <Typography variant="body2" sx={{ mt: 1 }}><b>Alamat:</b> {selectedOutlet.address}</Typography>
                        <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
                            <Button variant="contained" startIcon={<EditIcon />} onClick={() => handleEdit(selectedOutlet)}>Edit Frontliner</Button>
                            <Button variant="outlined" color="error" onClick={() => { removeOutlet(selectedOutlet.id); setSelectedOutlet(null); }}>Hapus Outlet</Button>
                        </Box>
                    </CardContent>
                </Card>
            )}

            <Dialog open={!!editDialog} onClose={() => setEditDialog(null)} maxWidth="sm" fullWidth>
                <DialogTitle sx={{ bgcolor: 'primary.main', color: 'white', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><EditIcon /> Edit Outlet</Box>
                    <IconButton onClick={() => setEditDialog(null)} sx={{ color: 'white' }}><CloseIcon /></IconButton>
                </DialogTitle>
                <DialogContent sx={{ pt: 3 }}>
                    <Grid container spacing={2}>
                        <Grid size={12}>
                            <Typography variant="subtitle2" color="primary.main" gutterBottom>Ubah Frontliner</Typography>
                            <FormControl fullWidth>
                                <InputLabel>Frontliner</InputLabel>
                                <Select value={editForm.frontliner || ''} label="Frontliner" onChange={(e) => setEditForm({ ...editForm, frontliner: e.target.value })}>
                                    {frontliners.map((fl) => (<MenuItem key={fl} value={fl}>{fl}</MenuItem>))}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            <TextField label="RTG / Freezer" fullWidth select value={editForm.rtgFreezer || 'None'} onChange={(e) => setEditForm({ ...editForm, rtgFreezer: e.target.value })}>
                                {RTG_LABELS.map((label) => (
                                    <MenuItem key={label} value={label}>
                                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                            {getRTGIcon(label)}
                                            {label}
                                        </Box>
                                    </MenuItem>
                                ))}
                            </TextField>
                        </Grid>
                        <Grid size={{ xs: 12, sm: 6 }}>
                            <TextField label="Account" fullWidth value={editForm.account || ''} onChange={(e) => setEditForm({ ...editForm, account: e.target.value })} />
                        </Grid>
                    </Grid>
                </DialogContent>
                <DialogActions sx={{ p: 2 }}>
                    <Button onClick={() => setEditDialog(null)} variant="outlined">Batal</Button>
                    <Button onClick={handleSaveEdit} variant="contained" color="primary">Simpan</Button>
                </DialogActions>
            </Dialog>

            <Dialog open={!!colorDialog} onClose={() => setColorDialog(null)} maxWidth="xs" fullWidth>
                <DialogTitle sx={{ bgcolor: 'primary.main', color: 'white', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <PaletteIcon /> Pilih Warna untuk {selectedColorName?.split(' ').slice(0, 2).join(' ')}
                    </Box>
                    <IconButton onClick={() => setColorDialog(null)} sx={{ color: 'white' }}><CloseIcon /></IconButton>
                </DialogTitle>
                <DialogContent sx={{ pt: 3 }}>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>Klik salah satu warna di bawah:</Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                        {COLOR_PICKER_PALETTE.map((color) => (
                            <Box key={color} onClick={() => handleSaveColor(color)} sx={{
                                width: 40, height: 40, bgcolor: color, borderRadius: 2, cursor: 'pointer',
                                border: getColorForFrontliner(selectedColorName) === color ? '3px solid #333' : '2px solid #e0e0e0',
                                transition: 'transform 0.2s', '&:hover': { transform: 'scale(1.15)' }
                            }} />
                        ))}
                    </Box>
                    <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>Atau masukkan kode warna sendiri:</Typography>
                    <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                        <input type="color" defaultValue={getColorForFrontliner(selectedColorName)} onChange={(e) => handleSaveColor(e.target.value)} style={{ width: 50, height: 40, border: 'none', cursor: 'pointer' }} />
                        <TextField size="small" placeholder="#C41E3A" onChange={(e) => { if (/^#[0-9A-Fa-f]{6}$/.test(e.target.value)) handleSaveColor(e.target.value); }} sx={{ flex: 1 }} />
                    </Box>
                    {customColors[selectedColorName] && (
                        <Button onClick={handleResetColor} variant="outlined" color="error" fullWidth sx={{ mt: 2 }}>?? Reset ke Warna Otomatis</Button>
                    )}
                </DialogContent>
            </Dialog>
        </Box>
    );
};

export default MapPage;