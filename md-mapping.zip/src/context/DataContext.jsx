import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { ref, set, onValue, remove, update } from "firebase/database";
import { db } from '../firebase';

const DataContext = createContext(null);

export const DataProvider = ({ children }) => {
    const [outlets, setOutlets] = useState([]);
    const [frontliners, setFrontliners] = useState([]);
    const [customColors, setCustomColors] = useState({});

    // Ambil data outlets
    useEffect(() => {
        const outletsRef = ref(db, 'outlets');
        const unsubscribe = onValue(outletsRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                const outletList = Object.values(data);
                setOutlets(outletList);
                const uniqueFL = [...new Set(outletList.map(o => o.frontliner).filter(Boolean))];
                setFrontliners(uniqueFL);
            } else {
                setOutlets([]);
                setFrontliners([]);
            }
        });
        return () => unsubscribe();
    }, []);

    // Ambil custom colors
    useEffect(() => {
        const colorsRef = ref(db, 'customColors');
        const unsubscribe = onValue(colorsRef, (snapshot) => {
            const data = snapshot.val();
            if (data) setCustomColors(data);
        });
        return () => unsubscribe();
    }, []);

    const addOutlets = useCallback((newOutlets) => {
        newOutlets.forEach(outlet => {
            set(ref(db, `outlets/${outlet.id}`), outlet);
        });
    }, []);

    // PERBAIKAN: Gunakan update() untuk merge data, bukan replace
    const updateOutlet = useCallback((id, updates) => {
        const outletRef = ref(db, `outlets/${id}`);
        update(outletRef, updates);
    }, []);

    const removeOutlet = useCallback((id) => {
        remove(ref(db, `outlets/${id}`));
    }, []);

    const clearAll = useCallback(() => {
        remove(ref(db, 'outlets'));
    }, []);

    const updateCustomColor = useCallback((frontliner, color) => {
        set(ref(db, `customColors/${frontliner}`), color);
    }, []);

    return (
        <DataContext.Provider value={{
            outlets, frontliners, customColors,
            addOutlets, updateOutlet, removeOutlet, clearAll, updateCustomColor
        }}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => {
    const context = useContext(DataContext);
    if (!context) throw new Error('useData harus di dalam DataProvider');
    return context;
};