import Papa from 'papaparse';

export const parseCSV = (file) => {
    return new Promise((resolve, reject) => {
        Papa.parse(file, {
            header: true,
            skipEmptyLines: true,
            complete: (results) => {
                const data = results.data.map((row, index) => ({
                    id: index + 1,
                    frontliner: row['Frontliner'] || row['frontliner'] || '',
                    outletId: row['Outlet ID'] || row['outlet_id'] || row['OutletID'] || '',
                    outletName: row['Outlet Name'] || row['outlet_name'] || row['OutletName'] || '',
                    city: row['City'] || row['city'] || '',
                    district: row['District'] || row['district'] || '',
                    account: row['Account'] || row['account'] || '',
                    latitude: parseFloat(row['Latitude'] || row['latitude'] || 0),
                    longitude: parseFloat(row['Longitude'] || row['longitude'] || 0),
                    address: row['Adress'] || row['Address'] || row['adress'] || row['address'] || '',
                    rtgFreezer: row['RTG_Freezer'] || row['rtg_freezer'] || row['RTG/Freezer'] || 'None',
                }));
                resolve(data);
            },
            error: (error) => {
                reject(error);
            },
        });
    });
};

export const exportCSV = (data) => {
    const csv = Papa.unparse(
        data.map((d) => ({
            Frontliner: d.frontliner,
            'Outlet ID': d.outletId,
            'Outlet Name': d.outletName,
            City: d.city,
            District: d.district,
            Account: d.account,
            Latitude: d.latitude,
            Longitude: d.longitude,
            Address: d.address,
            RTG_Freezer: d.rtgFreezer,
        }))
    );
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'md_mapping_data.csv');
    link.click();
    URL.revokeObjectURL(url);
};

export const downloadTemplate = () => {
    const template = [
        {
            Frontliner: 'YANAS MUHAMMAD SUPRIATNA',
            'Outlet ID': '11102376',
            'Outlet Name': 'Alfa Cisaranten Endah',
            City: 'Kota Bandung',
            District: 'Arcamanik',
            Account: 'Alfamart',
            Latitude: -6.9280617,
            Longitude: 107.67242,
            Address: 'Jl. Cingised No.83, Cisaranten Endah, Kec. Arcamanik',
            RTG_Freezer: 'RTG',
        },
    ];
    const csv = Papa.unparse(template);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'template_md_mapping.csv');
    link.click();
    URL.revokeObjectURL(url);
};