import { createTheme } from '@mui/material/styles';

const fiestaTheme = createTheme({
    palette: {
        primary: {
            main: '#C41E3A',        // Fiesta Red
            light: '#E8455A',
            dark: '#9B1B30',
            contrastText: '#FFFFFF',
        },
        secondary: {
            main: '#FF6B6B',
            light: '#FF8E8E',
            dark: '#CC4444',
        },
        background: {
            default: '#FFF5F5',
            paper: '#FFFFFF',
        },
        text: {
            primary: '#2D2D2D',
            secondary: '#6B6B6B',
        },
    },
    typography: {
        fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
        h4: {
            fontWeight: 700,
        },
        h5: {
            fontWeight: 600,
        },
        h6: {
            fontWeight: 600,
        },
    },
    shape: {
        borderRadius: 12,
    },
    components: {
        MuiButton: {
            styleOverrides: {
                root: {
                    textTransform: 'none',
                    fontWeight: 600,
                    borderRadius: 10,
                    padding: '10px 24px',
                },
            },
        },
        MuiCard: {
            styleOverrides: {
                root: {
                    borderRadius: 16,
                    boxShadow: '0 4px 20px rgba(196, 30, 58, 0.08)',
                },
            },
        },
        MuiAppBar: {
            styleOverrides: {
                root: {
                    boxShadow: '0 2px 12px rgba(196, 30, 58, 0.15)',
                },
            },
        },
    },
});

export default fiestaTheme;